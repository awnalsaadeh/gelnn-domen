"use client";
import { useState } from "react";
import BottomNav from "@/components/BottomNav";
import { DEFAULT_CATEGORIES } from "@/lib/doman";

type Language = "ar" | "en" | "es";
type CardSize = "large" | "medium" | "small";

const SIZE_CONFIG: Record<CardSize, { label: string; width: string; height: string; fontSize: string }> = {
  large: { label: "كبير (A5)", width: "14cm", height: "10cm", fontSize: "3.5cm" },
  medium: { label: "متوسط", width: "10cm", height: "7cm", fontSize: "2.5cm" },
  small: { label: "صغير", width: "8cm", height: "5.5cm", fontSize: "1.8cm" },
};

export default function PrintPage() {
  const [selectedCat, setSelectedCat] = useState<string>("all");
  const [cardSize, setCardSize] = useState<CardSize>("large");
  const [language, setLanguage] = useState<Language>("ar");
  const [showBothLangs, setShowBothLangs] = useState(false);

  const categoriesToShow =
    selectedCat === "all"
      ? DEFAULT_CATEGORIES
      : DEFAULT_CATEGORIES.filter((_, i) => `cat-${i}` === selectedCat);

  const getWordText = (word: (typeof DEFAULT_CATEGORIES[0]["words"][0])) => {
    if (language === "ar") return word.text_ar;
    if (language === "en") return word.text_en;
    return word.text_es;
  };

  const handlePrint = () => {
    window.print();
  };

  const sizeConfig = SIZE_CONFIG[cardSize];

  return (
    <>
      {/* Screen UI - hidden during print */}
      <div className="no-print min-h-screen pb-24 md:pr-64" dir="rtl">
        <BottomNav />

        <header className="px-5 pt-6 pb-4 md:px-8">
          <h1 className="text-3xl font-black text-brand-900">طباعة البطاقات 🖨️</h1>
          <p className="text-brand-600 font-medium mt-1">
            اضبط الإعدادات ثم اضغط طباعة
          </p>
        </header>

        <div className="px-5 md:px-8 space-y-5">
          {/* Category selector */}
          <div className="card p-4">
            <h3 className="font-black text-brand-900 mb-3">الفئة</h3>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setSelectedCat("all")}
                className={`p-3 rounded-2xl font-bold text-right border-2 transition-all ${
                  selectedCat === "all"
                    ? "border-brand-500 bg-brand-50 text-brand-700"
                    : "border-brand-100 bg-white text-brand-600"
                }`}
              >
                <span className="text-xl">📚</span>
                <span className="block text-sm">كل الفئات</span>
              </button>
              {DEFAULT_CATEGORIES.map((cat, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedCat(`cat-${i}`)}
                  className={`p-3 rounded-2xl font-bold text-right border-2 transition-all ${
                    selectedCat === `cat-${i}`
                      ? "border-brand-500 bg-brand-50 text-brand-700"
                      : "border-brand-100 bg-white text-brand-600"
                  }`}
                >
                  <span className="text-xl">{cat.emoji}</span>
                  <span className="block text-sm">{cat.name_ar}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Card size */}
          <div className="card p-4">
            <h3 className="font-black text-brand-900 mb-3">حجم البطاقة</h3>
            <div className="flex gap-2">
              {(Object.keys(SIZE_CONFIG) as CardSize[]).map((size) => (
                <button
                  key={size}
                  onClick={() => setCardSize(size)}
                  className={`flex-1 py-3 rounded-2xl font-bold text-sm border-2 transition-all ${
                    cardSize === size
                      ? "border-brand-500 bg-brand-50 text-brand-700"
                      : "border-brand-100 bg-white text-brand-600"
                  }`}
                >
                  {SIZE_CONFIG[size].label}
                </button>
              ))}
            </div>
          </div>

          {/* Language */}
          <div className="card p-4">
            <h3 className="font-black text-brand-900 mb-3">اللغة</h3>
            <div className="flex gap-2">
              {(["ar", "en", "es"] as Language[]).map((lang) => {
                const labels = { ar: "عربي", en: "English", es: "Español" };
                return (
                  <button
                    key={lang}
                    onClick={() => setLanguage(lang)}
                    className={`flex-1 py-3 rounded-2xl font-bold text-sm border-2 transition-all ${
                      language === lang
                        ? "border-brand-500 bg-brand-50 text-brand-700"
                        : "border-brand-100 bg-white text-brand-600"
                    }`}
                  >
                    {labels[lang]}
                  </button>
                );
              })}
            </div>
            <label className="flex items-center gap-3 mt-3 cursor-pointer">
              <input
                type="checkbox"
                checked={showBothLangs}
                onChange={(e) => setShowBothLangs(e.target.checked)}
                className="w-5 h-5 accent-brand-500"
              />
              <span className="font-bold text-brand-700">إظهار العربية والإنجليزية معاً</span>
            </label>
          </div>

          {/* Preview count */}
          <div className="bg-brand-50 border-2 border-brand-200 rounded-2xl p-4 text-center">
            <p className="font-bold text-brand-700">
              سيتم طباعة{" "}
              <span className="font-black text-brand-900 text-xl">
                {categoriesToShow.reduce((a, c) => a + c.words.length, 0)}
              </span>{" "}
              بطاقة
            </p>
          </div>

          {/* Print button */}
          <button
            onClick={handlePrint}
            className="w-full bg-brand-500 hover:bg-brand-600 text-white font-black text-xl py-5 rounded-3xl transition-all active:scale-95 shadow-xl shadow-brand-200 flex items-center justify-center gap-3"
          >
            <span>🖨️</span>
            <span>طباعة الآن</span>
          </button>

          {/* Tips */}
          <div className="card p-4 bg-amber-50 border border-amber-200">
            <h3 className="font-black text-amber-900 mb-2">💡 نصائح الطباعة</h3>
            <ul className="space-y-1.5 text-sm text-amber-800 font-medium">
              <li>• اختر &quot;مقياس الطباعة&quot; = 100%</li>
              <li>• ورق أبيض سميك (250 جرام) أفضل</li>
              <li>• استخدمي حامل البطاقة لتسهيل العرض</li>
              <li>• وفقاً لدومان: الخط الأحمر الكبير هو الأفضل</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Print-only content */}
      <div className="hidden print:block" dir="rtl">
        <style>{`
          @page {
            margin: 1cm;
            size: A4;
          }
          .print-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5cm;
            padding: 0;
          }
          .print-card {
            width: ${sizeConfig.width};
            height: ${sizeConfig.height};
            border: 3px solid #D4780A;
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            page-break-inside: avoid;
            padding: 0.5cm;
            box-sizing: border-box;
          }
          .print-word {
            font-size: ${sizeConfig.fontSize};
            font-weight: 900;
            color: #D4780A;
            font-family: 'Cairo', sans-serif;
            text-align: center;
            line-height: 1.2;
          }
          .print-word-en {
            font-size: calc(${sizeConfig.fontSize} * 0.4);
            color: #A85C08;
            font-family: 'Cairo', sans-serif;
            text-align: center;
            margin-top: 0.2cm;
          }
          .category-header {
            font-size: 0.8cm;
            font-weight: 900;
            color: #2D1800;
            margin-top: 0.5cm;
            margin-bottom: 0.3cm;
            padding-bottom: 0.2cm;
            border-bottom: 2px solid #D4780A;
            width: 100%;
            text-align: right;
          }
        `}</style>

        {categoriesToShow.map((cat, ci) => (
          <div key={ci}>
            <div className="category-header">
              {cat.emoji} {cat.name_ar}
            </div>
            <div className="print-grid">
              {cat.words.map((word, wi) => (
                <div key={wi} className="print-card">
                  <div className="print-word">{getWordText(word)}</div>
                  {showBothLangs && language === "ar" && (
                    <div className="print-word-en">{word.text_en}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
