"use client";
import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import BottomNav from "@/components/BottomNav";
import { DOMAN_RULES } from "@/lib/doman";

// Sample words for demo
const DEMO_SETS = [
  {
    id: 1,
    name: "أفراد العائلة",
    emoji: "👨‍👩‍👧‍👦",
    color: "#E07B54",
    bgColor: "#FFF3EE",
    words: [
      { id: "w1", text_ar: "أمي", text_en: "Mommy", text_es: "Mamá" },
      { id: "w2", text_ar: "أبي", text_en: "Daddy", text_es: "Papá" },
      { id: "w3", text_ar: "أخي", text_en: "Brother", text_es: "Hermano" },
      { id: "w4", text_ar: "أختي", text_en: "Sister", text_es: "Hermana" },
      { id: "w5", text_ar: "جدتي", text_en: "Grandma", text_es: "Abuela" },
    ],
  },
  {
    id: 2,
    name: "أجزاء الجسم",
    emoji: "🧠",
    color: "#D4780A",
    bgColor: "#FFF8ED",
    words: [
      { id: "w6", text_ar: "يد", text_en: "Hand", text_es: "Mano" },
      { id: "w7", text_ar: "عين", text_en: "Eye", text_es: "Ojo" },
      { id: "w8", text_ar: "أنف", text_en: "Nose", text_es: "Nariz" },
      { id: "w9", text_ar: "فم", text_en: "Mouth", text_es: "Boca" },
      { id: "w10", text_ar: "قدم", text_en: "Foot", text_es: "Pie" },
    ],
  },
  {
    id: 3,
    name: "الألوان",
    emoji: "🎨",
    color: "#7C3AED",
    bgColor: "#F5F3FF",
    words: [
      { id: "w11", text_ar: "أحمر", text_en: "Red", text_es: "Rojo" },
      { id: "w12", text_ar: "أزرق", text_en: "Blue", text_es: "Azul" },
      { id: "w13", text_ar: "أخضر", text_en: "Green", text_es: "Verde" },
      { id: "w14", text_ar: "أصفر", text_en: "Yellow", text_es: "Amarillo" },
      { id: "w15", text_ar: "أبيض", text_en: "White", text_es: "Blanco" },
    ],
  },
];

type FlashState = "idle" | "countdown" | "flashing" | "between" | "done";

export default function FlashPage() {
  const [sessionNumber, setSessionNumber] = useState(2); // Demo: session 2
  const [currentSetIndex, setCurrentSetIndex] = useState(0);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [flashState, setFlashState] = useState<FlashState>("idle");
  const [countdown, setCountdown] = useState(3);
  const [completedSets, setCompletedSets] = useState<number[]>([]);
  const [displayLang, setDisplayLang] = useState<"ar" | "en" | "es">("ar");
  const [showCelebration, setShowCelebration] = useState(false);

  const currentSet = DEMO_SETS[currentSetIndex];
  const currentWord = currentSet?.words[currentWordIndex];
  const allDone = completedSets.length === DEMO_SETS.length;

  // Auto-advance words during flash
  useEffect(() => {
    if (flashState !== "flashing") return;

    const wordDuration = (DOMAN_RULES.SECONDS_PER_CARD * 1000) + 200; // 1.2 seconds per word

    const timer = setTimeout(() => {
      if (currentWordIndex < currentSet.words.length - 1) {
        setCurrentWordIndex((i) => i + 1);
      } else {
        // Set complete
        setFlashState("between");
        setCompletedSets((prev) => [...prev, currentSet.id]);
      }
    }, wordDuration);

    return () => clearTimeout(timer);
  }, [flashState, currentWordIndex, currentSet]);

  // Countdown
  useEffect(() => {
    if (flashState !== "countdown") return;
    if (countdown <= 0) {
      setFlashState("flashing");
      setCurrentWordIndex(0);
      return;
    }
    const timer = setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [flashState, countdown]);

  const startSet = useCallback(() => {
    setFlashState("countdown");
    setCountdown(3);
    setCurrentWordIndex(0);
  }, []);

  const nextSet = useCallback(() => {
    if (currentSetIndex < DEMO_SETS.length - 1) {
      setCurrentSetIndex((i) => i + 1);
      setFlashState("idle");
      setCurrentWordIndex(0);
    } else {
      setShowCelebration(true);
      setFlashState("done");
    }
  }, [currentSetIndex]);

  const getWordText = (word: (typeof DEMO_SETS[0]["words"][0]) | undefined) => {
    if (!word) return "";
    if (displayLang === "ar") return word.text_ar;
    if (displayLang === "en") return word.text_en;
    return word.text_es;
  };

  return (
    <div className="min-h-screen pb-24 md:pr-64" dir="rtl">
      <BottomNav />

      {/* Full-screen flash mode */}
      {flashState === "flashing" && currentWord && (
        <div
          className="fixed inset-0 z-50 flex flex-col items-center justify-center"
          style={{ backgroundColor: currentSet.bgColor }}
        >
          {/* Word display */}
          <div key={`${currentWordIndex}-${currentWord.id}`} className="word-flash text-center px-8">
            <p
              className="font-black leading-none select-none"
              style={{
                fontSize: "clamp(4rem, 20vw, 12rem)",
                color: currentSet.color,
                fontFamily: "'Cairo', sans-serif",
                textShadow: `0 4px 20px ${currentSet.color}33`,
              }}
            >
              {getWordText(currentWord)}
            </p>
          </div>

          {/* Progress dots */}
          <div className="absolute bottom-20 flex gap-2">
            {currentSet.words.map((_, i) => (
              <div
                key={i}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  i < currentWordIndex
                    ? "opacity-100 scale-125"
                    : i === currentWordIndex
                    ? "scale-150"
                    : "opacity-30"
                }`}
                style={{
                  backgroundColor: currentSet.color,
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Countdown overlay */}
      {flashState === "countdown" && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ backgroundColor: currentSet.bgColor }}
        >
          <div className="text-center">
            <div
              className="font-black leading-none animate-bounce-soft"
              style={{
                fontSize: "10rem",
                color: currentSet.color,
              }}
            >
              {countdown === 0 ? "🌟" : countdown}
            </div>
            <p className="font-black text-2xl mt-4" style={{ color: currentSet.color }}>
              {countdown === 0 ? "ابدأي!" : "استعدي..."}
            </p>
          </div>
        </div>
      )}

      {/* Celebration */}
      {showCelebration && (
        <div className="fixed inset-0 z-50 bg-brand-500 flex flex-col items-center justify-center text-white text-center p-8">
          <div className="text-8xl mb-6 animate-bounce">🎉</div>
          <h2 className="text-4xl font-black mb-3">أحسنتِ!</h2>
          <p className="text-xl font-bold opacity-90 mb-2">
            أتممتِ الجلسة {sessionNumber} من {DOMAN_RULES.SESSIONS_PER_DAY}
          </p>
          <p className="text-lg opacity-80 mb-8">
            عرضتِ {DEMO_SETS.length * DOMAN_RULES.WORDS_PER_SET} كلمة بنجاح 🌟
          </p>
          <div className="flex gap-3">
            <Link
              href="/dashboard"
              className="bg-white text-brand-600 font-black text-lg px-8 py-4 rounded-3xl active:scale-95"
            >
              العودة للرئيسية
            </Link>
          </div>
          <p className="mt-6 text-sm opacity-70 max-w-sm">
            الجلسة التالية الساعة ٤:٠٠ م · تذكري: لا تختبري نورة ولا تكرري البطاقات 💕
          </p>
        </div>
      )}

      {/* Main content */}
      {!showCelebration && flashState !== "flashing" && flashState !== "countdown" && (
        <>
          {/* Header */}
          <header className="px-5 pt-6 pb-4 md:px-8 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-black text-brand-900">
                الجلسة {sessionNumber} من {DOMAN_RULES.SESSIONS_PER_DAY}
              </h1>
              <p className="text-brand-600 font-medium">
                {completedSets.length} / {DEMO_SETS.length} مجموعات مكتملة
              </p>
            </div>
            {/* Language selector */}
            <div className="flex gap-1 bg-brand-50 rounded-2xl p-1 border border-brand-100">
              {(["ar", "en", "es"] as const).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setDisplayLang(lang)}
                  className={`px-3 py-1.5 rounded-xl font-bold text-sm transition-all ${
                    displayLang === lang
                      ? "bg-brand-500 text-white shadow"
                      : "text-brand-600 hover:bg-brand-100"
                  }`}
                >
                  {lang === "ar" ? "ع" : lang === "en" ? "EN" : "ES"}
                </button>
              ))}
            </div>
          </header>

          {/* Glenn Doman reminder banner */}
          <div className="mx-5 md:mx-8 mb-4 bg-amber-50 border border-amber-200 rounded-2xl p-3 flex items-center gap-3">
            <span className="text-2xl">💡</span>
            <p className="text-sm font-bold text-amber-800">
              اعرضي كل بطاقة بسرعة • لا تختبري الطفلة • احتفلي بكل جلسة 🌟
            </p>
          </div>

          {/* Sets list */}
          <div className="px-5 md:px-8 space-y-4">
            {DEMO_SETS.map((set, index) => {
              const isCompleted = completedSets.includes(set.id);
              const isCurrent = index === currentSetIndex;

              return (
                <div
                  key={set.id}
                  className={`card p-5 transition-all ${
                    isCompleted ? "opacity-50" : isCurrent ? "ring-2 ring-brand-400" : ""
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl"
                        style={{ backgroundColor: set.bgColor }}
                      >
                        {set.emoji}
                      </div>
                      <div>
                        <h3 className="font-black text-brand-900">{set.name}</h3>
                        <p className="text-sm text-brand-600 font-medium">
                          {set.words.length} كلمات
                        </p>
                      </div>
                    </div>

                    {isCompleted ? (
                      <div className="flex items-center gap-2 bg-green-100 text-green-700 font-black px-4 py-2 rounded-2xl">
                        <span>✓</span>
                        <span>مكتملة</span>
                      </div>
                    ) : isCurrent && flashState === "between" ? (
                      <button
                        onClick={nextSet}
                        className="bg-brand-500 hover:bg-brand-600 text-white font-black px-5 py-2.5 rounded-2xl transition-all active:scale-95 shadow-md"
                      >
                        التالية →
                      </button>
                    ) : isCurrent ? (
                      <button
                        onClick={startSet}
                        className="bg-brand-500 hover:bg-brand-600 text-white font-black px-5 py-2.5 rounded-2xl transition-all active:scale-95 shadow-md shadow-brand-200"
                        style={{ backgroundColor: set.color }}
                      >
                        ▶ ابدأ
                      </button>
                    ) : (
                      <div className="text-brand-300 font-bold text-sm">قريباً</div>
                    )}
                  </div>

                  {/* Word preview */}
                  {!isCompleted && (
                    <div className="mt-4 flex flex-wrap gap-2">
                      {set.words.map((word) => (
                        <span
                          key={word.id}
                          className="text-sm font-bold px-3 py-1.5 rounded-xl border"
                          style={{
                            backgroundColor: set.bgColor,
                            borderColor: `${set.color}40`,
                            color: set.color,
                          }}
                        >
                          {getWordText(word)}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Between sets message */}
                  {isCurrent && flashState === "between" && (
                    <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-xl text-center">
                      <p className="font-bold text-green-800">🎉 ممتاز! مجموعة {set.name} اكتملت</p>
                      <p className="text-sm text-green-700 mt-1">
                        استريحي قليلاً ثم انتقلي للمجموعة التالية
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
