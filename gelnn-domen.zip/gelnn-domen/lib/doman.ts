/**
 * Glenn Doman Methodology Engine
 * 
 * Based on "How to Teach Your Baby to Read" by Glenn Doman
 * 
 * Core Rules:
 * - 5 sets of 5 words each (25 words total)
 * - Each set shown 3 times per day
 * - Each word shown for 5 days, then retired (15 total showings)
 * - Add 1 new word per set per day after the first week
 * - Sessions must be joyful, brief, and enthusiastic
 * - NEVER test the child
 * - Show cards quickly (1 second per card)
 */

export const DOMAN_RULES = {
  WORDS_PER_SET: 5,
  SETS_PER_DAY: 5,
  SESSIONS_PER_DAY: 3,        // Show each set 3 times per day
  DAYS_PER_WORD: 5,           // Each word shown for 5 days then retired
  TOTAL_SHOWINGS_PER_WORD: 15, // 3 sessions × 5 days = 15 times
  SECONDS_PER_CARD: 1,        // Flash each card for 1 second
  NEW_WORDS_PER_DAY: 1,       // Add 1 new word per set per day (after setup)
  TOTAL_STARTING_WORDS: 25,   // 5 sets × 5 words
  MIN_SESSION_GAP_MINUTES: 30, // At least 30 min between sessions
};

/**
 * Predefined word categories in Arabic with translations
 * These follow Glenn Doman's recommended starting categories
 */
export const DEFAULT_CATEGORIES = [
  {
    name_ar: "أفراد العائلة",
    name_en: "Family Members",
    name_es: "Miembros de la Familia",
    color: "#E07B54",
    emoji: "👨‍👩‍👧‍👦",
    words: [
      { text_ar: "أمي", text_en: "Mommy", text_es: "Mamá" },
      { text_ar: "أبي", text_en: "Daddy", text_es: "Papá" },
      { text_ar: "أخي", text_en: "Brother", text_es: "Hermano" },
      { text_ar: "أختي", text_en: "Sister", text_es: "Hermana" },
      { text_ar: "جدتي", text_en: "Grandma", text_es: "Abuela" },
    ],
  },
  {
    name_ar: "أجزاء الجسم",
    name_en: "Body Parts",
    name_es: "Partes del Cuerpo",
    color: "#D4780A",
    emoji: "🧠",
    words: [
      { text_ar: "يد", text_en: "Hand", text_es: "Mano" },
      { text_ar: "عين", text_en: "Eye", text_es: "Ojo" },
      { text_ar: "أنف", text_en: "Nose", text_es: "Nariz" },
      { text_ar: "فم", text_en: "Mouth", text_es: "Boca" },
      { text_ar: "قدم", text_en: "Foot", text_es: "Pie" },
    ],
  },
  {
    name_ar: "الألوان",
    name_en: "Colors",
    name_es: "Colores",
    color: "#7C3AED",
    emoji: "🎨",
    words: [
      { text_ar: "أحمر", text_en: "Red", text_es: "Rojo" },
      { text_ar: "أزرق", text_en: "Blue", text_es: "Azul" },
      { text_ar: "أخضر", text_en: "Green", text_es: "Verde" },
      { text_ar: "أصفر", text_en: "Yellow", text_es: "Amarillo" },
      { text_ar: "أبيض", text_en: "White", text_es: "Blanco" },
    ],
  },
  {
    name_ar: "الحيوانات",
    name_en: "Animals",
    name_es: "Animales",
    color: "#059669",
    emoji: "🐾",
    words: [
      { text_ar: "قطة", text_en: "Cat", text_es: "Gato" },
      { text_ar: "كلب", text_en: "Dog", text_es: "Perro" },
      { text_ar: "أسد", text_en: "Lion", text_es: "León" },
      { text_ar: "فيل", text_en: "Elephant", text_es: "Elefante" },
      { text_ar: "طائر", text_en: "Bird", text_es: "Pájaro" },
    ],
  },
  {
    name_ar: "الطعام",
    name_en: "Food",
    name_es: "Comida",
    color: "#DC2626",
    emoji: "🍎",
    words: [
      { text_ar: "تفاحة", text_en: "Apple", text_es: "Manzana" },
      { text_ar: "موزة", text_en: "Banana", text_es: "Plátano" },
      { text_ar: "حليب", text_en: "Milk", text_es: "Leche" },
      { text_ar: "خبز", text_en: "Bread", text_es: "Pan" },
      { text_ar: "ماء", text_en: "Water", text_es: "Agua" },
    ],
  },
];

/**
 * Calculate which words should be shown today based on the Doman schedule
 * Returns sets of 5 words for each of the 3 daily sessions
 */
export function getTodaysSchedule(
  activeWords: Array<{ id: string; text_ar: string; category_id: string; introduced_at: string | null; times_shown: number }>,
  today: Date = new Date()
): Array<{ setNumber: number; words: typeof activeWords }> {
  // Group words by category (each category = 1 set of 5)
  const categoryMap = new Map<string, typeof activeWords>();
  
  for (const word of activeWords) {
    if (!categoryMap.has(word.category_id)) {
      categoryMap.set(word.category_id, []);
    }
    const catWords = categoryMap.get(word.category_id)!;
    if (catWords.length < DOMAN_RULES.WORDS_PER_SET) {
      catWords.push(word);
    }
  }

  const sets: Array<{ setNumber: number; words: typeof activeWords }> = [];
  let setNumber = 1;
  
  for (const [, words] of categoryMap) {
    if (words.length > 0) {
      sets.push({ setNumber: setNumber++, words });
    }
    if (sets.length >= DOMAN_RULES.SETS_PER_DAY) break;
  }

  return sets;
}

/**
 * Check if a word should be retired (shown 15 times or 5 days passed)
 */
export function shouldRetireWord(word: {
  introduced_at: string | null;
  times_shown: number;
}): boolean {
  if (word.times_shown >= DOMAN_RULES.TOTAL_SHOWINGS_PER_WORD) return true;
  
  if (word.introduced_at) {
    const introduced = new Date(word.introduced_at);
    const today = new Date();
    const daysDiff = Math.floor(
      (today.getTime() - introduced.getTime()) / (1000 * 60 * 60 * 24)
    );
    if (daysDiff >= DOMAN_RULES.DAYS_PER_WORD) return true;
  }
  
  return false;
}

/**
 * Get session times for today
 * Glenn Doman recommends spreading sessions through the day
 */
export function getSessionTimes(): string[] {
  return ["صباحاً ٨:٠٠", "ظهراً ١٢:٠٠", "مساءً ٤:٠٠"];
}

/**
 * Get motivational tip based on the Doman methodology
 */
export function getDomanTip(lang: "ar" | "en" | "es" = "ar"): string {
  const tips = {
    ar: [
      "🌟 اجعل الجلسة ممتعة وسعيدة دائماً",
      "⏱️ أظهر كل بطاقة بسرعة - ثانية واحدة لكل كلمة",
      "🚫 لا تختبر طفلك أبداً - التعلم لعبة وهو يفوز دائماً",
      "🔄 قدّم مواد جديدة باستمرار لتجنب الملل",
      "💕 احتضن طفلك وقبّله أثناء الجلسة",
      "⏰ أوقف الجلسة قبل أن يشعر طفلك بالملل",
      "✨ أنت المعلم الأفضل لطفلك - ثق بنفسك",
    ],
    en: [
      "🌟 Always make sessions joyful and happy",
      "⏱️ Flash each card quickly - 1 second per word",
      "🚫 Never test your child - learning is a game they always win",
      "🔄 Introduce new material constantly to prevent boredom",
      "💕 Hug and kiss your child during sessions",
      "⏰ Stop before your child gets bored",
      "✨ You are your child's best teacher - trust yourself",
    ],
    es: [
      "🌟 Haz que las sesiones siempre sean alegres",
      "⏱️ Muestra cada tarjeta rápidamente - 1 segundo por palabra",
      "🚫 Nunca examines a tu hijo - el aprendizaje es un juego que siempre gana",
      "🔄 Introduce material nuevo constantemente",
      "💕 Abraza y besa a tu hijo durante las sesiones",
      "⏰ Para antes de que tu hijo se aburra",
      "✨ Eres el mejor maestro de tu hijo - confía en ti",
    ],
  };
  
  const langTips = tips[lang];
  return langTips[Math.floor(Math.random() * langTips.length)];
}

/**
 * Get progress percentage for a word
 */
export function getWordProgress(timesShown: number): number {
  return Math.min(100, Math.round((timesShown / DOMAN_RULES.TOTAL_SHOWINGS_PER_WORD) * 100));
}
